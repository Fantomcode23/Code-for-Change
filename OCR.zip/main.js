(() => {
  
    let width = screen.width;
    let height = width / (4 / 3);
    let streaming = false;
  
    let video = null;
    let canvas = null;
    let but2 = null;
    let startbutton = null;
  
    function startup() {
     
      video = document.getElementById("video");
      canvas = document.getElementById("canvas");
      contibutton = document.getElementById("contibutton");
      startbutton = document.getElementById("startbutton");
      //console.log(gg);
      startbutton.style.left = "400px";
      contibutton.style.left = "620px";
      startbutton.style.top = "1300px";
      contibutton.style.top = "1300px";
      
      Img = document.getElementById("stillImg");
  
      navigator.mediaDevices
        .getUserMedia({ video: true, audio: false })
        .then((stream) => {
          video.srcObject = stream;
          video.play();
        })
        .catch((err) => {
          console.error(`An error occurred: ${err}`);
        });
  
      video.addEventListener(
        "canplay",
        (ev) => {
          if (!streaming) {
            height = video.videoHeight / (video.videoWidth / width);
  
            if (isNaN(height)) {
              height = width / (4 / 3);
            }
  
            video.setAttribute("width", width);
            video.setAttribute("height", height);
            canvas.setAttribute("width", width);
            canvas.setAttribute("height", height);
            
            streaming = true;
          }
        },
        false,
      );
  
      startbutton.addEventListener(
        "click",
        (ev) => {
          takepicture();
          ev.preventDefault();
        },
        false,
      );
    }

    function takepicture() {
      const context = canvas.getContext("2d");
      context.drawImage(video, 0, 0, width, height);
      const data = canvas.toDataURL("image/png");
      blob = dataURLtoBlob(data);
      Img.setAttribute("src",data);
      video.remove();
      canvas.remove();
      Tesseract.recognize(blob,'eng').then(({data: {text}}) => document.getElementById(("scannedtext")).textContent = text);
      startbutton.style.left="120px";
      startbutton.textContent = "Scan Again";
      contibutton.style.backgroundColor = "#6153BD";
      startbutton.addEventListener(
        "click",
        (ev) => {
          location.reload();
          ev.preventDefault();
        },
        false,
      );
    }

    function dataURLtoBlob(dataURL) {
      const parts = dataURL.split(';base64,');
      const contentType = parts[0].split(':')[1];
      const raw = window.atob(parts[1]);
      const rawLength = raw.length;
      const uInt8Array = new Uint8Array(rawLength);

      for (let i = 0; i < rawLength; ++i) {
          uInt8Array[i] = raw.charCodeAt(i);
      }

      return new Blob([uInt8Array], { type: contentType });
  }
    window.addEventListener("load", startup, false);
  })();
  